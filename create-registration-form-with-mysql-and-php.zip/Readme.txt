Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: makitweb@gmail.com
Tutorial Link: https://makitweb.com/create-registration-form-with-mysql-and-php/

#####

Instructions -

1. Import the attached users.sql in your database.
2. Update config.php.